# SIGET_Equipo1
Repositorio del Equipo 1 para el proyecto de la intensificación de Ingeniería del Software (Escuela Superior de Informática Ciudad Real).

Mantenimiento realizado por el Equipo 5
